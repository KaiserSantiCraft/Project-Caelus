
#include "I2Cdev.h"
#include "MPU6050.h"
#include "Wire.h"
#include <SD.h>
#include <SFE_BMP180.h>
#include <Wire.h>


File myFile;
MPU6050 sensor;
SFE_BMP180 bmp180;

double PresionNivelMar=1013.25;
int ax, ay, az;
int gx, gy, gz;

void setup() {
  Serial.begin(9600);   
  Wire.begin();           
  sensor.initialize();    
  Serial.println("Start");
  if (sensor.testConnection()) Serial.println("Sensor iniciado correctamente");
  else Serial.println("Error al iniciar el sensor");
    Serial.print("Iniciando SD ...");
  if (!SD.begin(4)) {
    Serial.println("No se pudo inicializar");
    return;
  }
  if (bmp180.begin())
    Serial.println("BMP180 iniciado correctamenten");
  else
  {
    Serial.println("Error al iniciar el BMP180");
    while(1);
  }
  Serial.println("inicializacion exitosa");
}

void loop() {
  sensor.getAcceleration(&ax, &ay, &az);
  sensor.getRotation(&gx, &gy, &gz);
  float ax_m_s2 = ax * (9.81/16384.0);
  float ay_m_s2 = ay * (9.81/16384.0);
  float az_m_s2 = az * (9.81/16384.0);
  float gx_deg_s = gx * (250.0/32768.0);
  float gy_deg_s = gy * (250.0/32768.0);
  float gz_deg_s = gz * (250.0/32768.0);
  char status;
  double T,P,A;
  
  status = bmp180.startTemperature();
  if (status != 0)
  {   
    delay(status); 
    status = bmp180.getTemperature(T);
    if (status != 0)
    {
      status = bmp180.startPressure(3);
      if (status != 0)
      {        
        delay(status);        
        status = bmp180.getPressure(P,T);
        if (status != 0)
        {                  
          Serial.print("Temperatura: ");
          Serial.print(T);
          Serial.print(" *C , ");
          Serial.print("Presion: ");
          Serial.print(P);
          Serial.print(" mb , ");     
          A= bmp180.altitude(P,PresionNivelMar);
          Serial.print("Altitud: ");
          Serial.print(A);
          Serial.println(" m s.n.m.");    
        }      
      }      
    }   
  }
  myFile = SD.open("datalog.csv", FILE_WRITE);
  
    if (myFile) { 
      myFile.print("a[x y z](m/s2) g[x y z](deg/s):\t");
      myFile.print(",");
      myFile.print(ax_m_s2);
      myFile.print(",");
      myFile.print(ay_m_s2); 
      myFile.print(",");
      myFile.print(az_m_s2);
      myFile.print(","); 
      myFile.print(gx_deg_s);
      myFile.print(",");
      myFile.print(gy_deg_s);
      myFile.print(","); 
      myFile.print(gz_deg_s);
      myFile.print(","); 
      myFile.print(T);
      myFile.print(","); 
      myFile.print(P);
      myFile.print(",");    
      myFile.print(A);
      myFile.print(","); 
      myFile.println(" m s.n.m.");  
      myFile.close();  
      Serial.print("a[x y z](m/s2) g[x y z](deg/s):\t");
      Serial.print(ax_m_s2); Serial.print("\t");
      Serial.print(ay_m_s2); Serial.print("\t");
      Serial.print(az_m_s2); Serial.print("\t");
      Serial.print(gx_deg_s); Serial.print("\t");
      Serial.print(gy_deg_s); Serial.print("\t");
      Serial.println(gz_deg_s);    
    } else {
      Serial.println("Error al abrir el archivo");
    }
    delay(1000);

}